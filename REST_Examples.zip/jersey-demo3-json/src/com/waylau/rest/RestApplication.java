package com.waylau.rest;

import org.codehaus.jackson.jaxrs.JacksonJsonProvider;  
import org.glassfish.jersey.filter.LoggingFilter;  
import org.glassfish.jersey.server.ResourceConfig;  

public class RestApplication extends ResourceConfig {  
    public RestApplication() {  

     
     packages("com.waylau.rest.resources");  
     
     register(JacksonJsonProvider.class);  

    }  
}  