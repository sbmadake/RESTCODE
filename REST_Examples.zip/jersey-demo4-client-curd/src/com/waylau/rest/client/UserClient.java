package com.waylau.rest.client;


import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.codehaus.jackson.jaxrs.JacksonJsonProvider;

import com.waylau.rest.bean.User;

 

public class UserClient {

	private static String serverUri = "http://localhost:8089/RestDemo/rest";
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		addUser();
		getAllUsers();
		updateUser();
		getUserById();
		getAllUsers();
		delUser();
		getAllUsers();

	}
	/**
	 * 添加用户
	 */
	 private static void addUser() {
		 System.out.println("****增加用户addUser****");
		 User user = new User("006","Susan","21");  
		 Client client = ClientBuilder.newClient();
		 WebTarget target = client.target(serverUri + "/users");
		 Response response = target.request().buildPost(Entity.entity(user, MediaType.APPLICATION_XML)).invoke();
		 response.close();
    }
	 
	 private static void delUser() {
		 System.out.println("****删除用户****");
		 Client client = ClientBuilder.newClient();
		 WebTarget target = client.target(serverUri + "/users/006");
		 Response response = target.request().delete();
		 response.close();
	}
	 
	
	 private static void updateUser() {
		 System.out.println("****修改用户updateUser****");
		 User user = new User("006","Susan","33");  
		 Client client = ClientBuilder.newClient();
		 WebTarget target = client.target(serverUri + "/users");
		 Response response = target.request().buildPut( Entity.entity(user, MediaType.APPLICATION_XML)).invoke();
		 response.close();
    }
	
	 private static void getUserById() {
		 
		 Client client = ClientBuilder.newClient().register(JacksonJsonProvider.class);// 注册json 支持
		 WebTarget target = client.target(serverUri + "/users/006");
		 Response response = target.request().get();
		 User user = response.readEntity(User.class);
		 System.out.println(user.getUserId() + user.getUserName()  +  user.getAge());
		 response.close();
    }
	
	 private static void getAllUsers() {
		 
		 
		 Client client = ClientBuilder.newClient();

		 WebTarget target = client.target(serverUri + "/users");
		 Response response = target.request().get();
		 String value = response.readEntity(String.class);
		 System.out.println(value);
		 response.close();  
	 }
	 
}
